%% section 4
% for equlibrium #1: x=0,y=0
around_00=-1.2:0.1:1.2;
[x1,y1]= meshgrid(around_00,around_00);
dx1=-4*x1+y1.^2;
dy1=5*(exp(y1-x1)-1);
%normalizing the field lines to see the small ones
size1=sqrt(dx1.^2+dy1.^2);
dx1=dx1./size1;
dy1=dy1./size1;
figure(1);
quiver(x1,y1,dx1,dy1,'AutoScaleFactor',0.4,'AutoScale','on');
title('equlibrium center in (0,0) field lines');
xlabel('x');
ylabel('y');
xlim([-1,1]);
ylim([-1,1]);


% for equlibrium #2: x=4,y=4
around_44=3:0.1:5;
[x2,y2]= meshgrid(around_44,around_44);
dx2=-4*x2+y2.^2;
dy2=5*(exp(y2-x2)-1);
%normalizing the field lines to see the small ones
size2=sqrt(dx2.^2+dy2.^2);
dx2=dx2./size2;
dy2=dy2./size2;
figure(2);
quiver(x2,y2,dx2,dy2,'AutoScaleFactor',0.4,'AutoScale','on');
title('equlibrium center in (0,0) field lines');
xlabel('x');
ylabel('y');
xlim([3,5]);
ylim([3,5]);

%% section 7

dt=1e-4;
maxT=0.5;
t=0:dt:maxT;
A=4;
x0=0.1;
y0=-0.1;

x=zeros(1,maxT/dt+1);
x(1)=x0;
y=zeros(1,maxT/dt+1);
y(1)=y0;

f = @(x,y) -4.*x+y.^2; 
g = @(x,y) 5.*(exp(y-x)-1);


for k=1:maxT/dt
    x(k+1)=x(k)+f(x(k),y(k))*dt;
    y(k+1)=y(k)+g(x(k),y(k))*dt;
end

figure(3);
plot(x,y );
hold on
quiver(x1,y1,dx1,dy1,'AutoScaleFactor',0.4,'AutoScale','on');
title('equlibrium center in (0,0) solution course');
legend('course','Field lines');
xlabel('x');
ylabel('y');
xlim([-1.2,1.2]);
ylim([-1.2,1.2]);
