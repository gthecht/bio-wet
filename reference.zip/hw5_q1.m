R=10;
theta = 40;
C=1;
Td=25;
T0=@(I) Td+R*C*log(abs((R*I)/(R*I-theta)));
f=zeros(40,1);
for ii=1:40
    if(ii*R>theta)
        f(ii)=1000/T0(ii);
    else
        f(ii)=0;
    end
end
figure(1);
I = 1*10^-6:1*10^-6:40*10^-6;
plot(I,f);
title("Firing Rate");
xlabel("I0(A)");
ylabel("f(I0)(HZ)")