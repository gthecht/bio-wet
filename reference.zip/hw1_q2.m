dt=0.01;
maxT=1000;
t=0:dt:maxT;
A=4;
x0=0.05;
r0=0;

x=zeros(1,maxT/dt+1);
x(1)=x0;
r=zeros(1,maxT/dt+1);
r(1)=r0;

f = @(x,r) r.*x.*(1-x./10) -(x.^2)./(1+x.^2); 
g = @(x) 0.011*(1-(x.^2)/A);


for k=1:maxT/dt
    x(k+1)=x(k)+f(x(k),r(k))*dt;
    r(k+1)=r(k)+g(x(k))*dt;
end
figure(1);
plot(t,x);
title('Population size as function of time');
xlabel('time');
ylabel('x(t)');

figure(2);
plot(t,r);
title('Population Growth rate size as function of time');
xlabel('time');
ylabel('r(t)');

figure(3);
plot(x,r);
title('Population Growth rate size as function of Population size');
xlabel('x(t)');
ylabel('r(t)');

